$(function() {
	var mainnav = $('#main-navigation a'),
		parnav = $('#partial-navigation a');
	mainnav.click(function() {
		mainnav.removeClass('active-tab');
		$(this).addClass('active-tab');
	});
	parnav.click(function() {
		parnav.removeClass('active-tab');
		$(this).addClass('active-tab');
	});
});
