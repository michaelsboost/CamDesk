
function start() {
  navigator.getUserMedia = (navigator.getUserMedia ||
                            navigator.webkitGetUserMedia ||
                            navigator.mozGetUserMedia ||
                            navigator.msGetUserMedia);

  navigator.getUserMedia({video:true}, onReady, console.error);
  function onReady(stream) {
    var view = document.querySelector(".view");
    var video = document.querySelector(".view > video");
    // video.addEventListener("click", rotate);
    view.dataset.active = true;
    video.src = window.URL.createObjectURL(stream);
    setTimeout(fitVideo, 500); // meh
  }
}

var rotated = false;

function rotate() {
  rotated = !rotated;
  fitVideo();
}

function fitVideo() {
  var video = document.querySelector(".view > video");

  var vWidth = video.videoWidth;
  var vHeight = video.videoHeight;
  var vRatio = vWidth / vHeight;

  var sWidth = rotated ? window.innerHeight : window.innerWidth;
  var sHeight = rotated ? window.innerWidth : window.innerHeight;
  var sRatio = sWidth / sHeight;

  if (sRatio < vRatio) {
    video.width = sWidth;
    video.removeAttribute("height");

    var new_vHeight = ~~(sWidth / vRatio);

    if (!rotated) {
      video.style.transform = "scaleY(" + sHeight / new_vHeight + ")";
    } else {
      video.style.transform = "translateX(" + sHeight + "px) rotate(90deg) scaleY(" + sHeight / new_vHeight + ")";
    }
  } else {
    video.height = sHeight;
    video.removeAttribute("width");

    var new_vWidth = ~~(sHeight * vRatio);
    if (!rotated) {
      video.style.transform = "scaleX(" + sWidth / new_vWidth + ")";
    } else {
      video.style.transform = "translateY(" + sWidth + "px) rotate(-90deg) scaleX(" + sWidth / new_vWidth + ")";
    }
  }

}

window.addEventListener("resize", fitVideo);
start();
